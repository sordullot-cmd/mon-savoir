---
name: inspi
description: À partir d'un lien (site web OU post social X/Twitter, Instagram, Pinterest, TikTok, Behance, Dribbble, YouTube, Vimeo…), crée une inspiration rangée par discipline. Site → capture tout le site (un screenshot par page) + fiche cherchable. Post social → télécharge le(s) média(s) du post (image/vidéo) + fiche. Appelé par /ranger quand un lien arrive, ou directement « ajoute ce site/post/pin/tweet en inspi ».
---

# /inspi — Inspiration depuis un lien (site web ou post social)

Transforme une **URL** en inspiration rangée : un **dossier** (dans sa discipline) contenant la **source + les visuels + une fiche** décrite → cherchable par allure.

**Deux modes selon l'URL** :
- **Site web** (défaut) → § Procédure (capture pleine hauteur de chaque page, composants, animations, walkthrough).
- **Post social** — l'URL pointe vers un post/pin/vidéo sur `x.com`/`twitter.com`, `instagram.com`, `pinterest.*`/`pin.it`, `tiktok.com`, `behance.net`, `dribbble.com`, `tumblr.com`, `bsky.app`, `threads.net`, `youtube.com`/`youtu.be`, `vimeo.com`… → § Mode post social (télécharger le média, pas screenshoter le site). Un lien vers le **profil** d'un compte ou la **home** d'une plateforme n'est PAS un post → demander à Sacha ce qu'il veut en garder.

## Procédure

1. **Récupérer l'URL** (donnée par Sacha, ou depuis un `.url/.webloc/.txt` de l'INBOX, ou une note ne contenant qu'un lien).
2. **Choisir la discipline** (= dossier de destination) : `WEBDESIGN` (défaut pour un site), `UI-DESIGN`, `BRAND-DESIGN`, `GRAPHISME`, `MOTION`. Si aucune ne colle, **créer une catégorie** (cf. règle dans `CLAUDE.md` — rester sobre). Si vraiment ambigu, demander.
3. **Slug** : `<domaine>` ou `<domaine>-<sujet>` en kebab (ex. `eliotdewolf`, `linear-pricing`). Destination = `INSPIRATION/<DISCIPLINE>/<slug>/`.
4. **Lire la page** (`WebFetch`) : titre, description, secteur, style → nourrit fiche + mood/tags.
5. **Capturer le site** (chaque page = capture **pleine hauteur**, via le protocole Chrome, pas juste le viewport) :
   ```
   python3 .claude/skills/inspi/capture-site.py "<url>" "INSPIRATION/<DISCIPLINE>/<slug>"
   ```
   - **Par défaut = tout le site, MAIS 1 page par template.** Les pages qui partagent un même template (ex. les fiches projet `/works/*`, les articles `/blog/*`) sont **regroupées** : on n'en capture **qu'une seule** comme exemple (`works-template.png`), pas les 10. Les pages racine uniques (`/`, `/about`, `/shop`…) sont toutes capturées. Le JSON liste les groupes regroupés (`templates_regroupés`) → le **signaler** (ex. « 10 pages projet → 1 capturée »).
   - **Forcer chaque page** (rare) : `--all-pages`.
   - **Seulement certaines pages** si Sacha le demande : `--pages "/,/about,/shop"` (la home seule = `--pages "/"`).
   - Options : `--max N` (def 25, plafond de sécurité), `--budget MS` (def 16000, délai de rendu).
   - Le script renvoie un JSON : pages capturées + regroupements + toute **troncature** (jamais silencieuse → la signaler).
6. **Regarder les captures** (`Read` `home.png` + 1-2 pages clés) — jugement : style, mood, couleurs, ce qui est intéressant. Repérer un **cookie-wall / loader** résiduel (cf. Limites).
7. **Créer la fiche** `INSPIRATION/<DISCIPLINE>/<slug>/<slug>.md` depuis `TEMPLATES/Template-Inspiration.md`. **Remplir TOUS les descripteurs** (c'est ce qui rend la recherche fine) — vocabulaire **contrôlé** listé dans `INSPIRATION/_INSPIRATION.md`, ne pas inventer de synonyme :
   - `discipline:` + `source:` (URL complète) + `media: site`
   - `type_site:` — déduit du contenu/WebFetch (portfolio, agence, saas, e-commerce, éditorial…)
   - `secteur:` — domaine métier (tech, mode, food, luxe…)
   - `couleur_principale:` — couleur dominante observée sur les captures, **nom + hex** (ex. `noir #0A0A0A`)
   - `couleurs:` — palette complète d'après les captures
   - `anime:` (`oui`/`non`/`léger`) + `animations:` — les types réellement repérés à la **passe animation** (§ ci-dessous) : `scroll-reveal`, `parallaxe`, `loader`, `hover`, `webgl-3d`, `video-bg`, `marquee`… (cohérent avec ce qui est gardé en GIF/MP4). Si site statique → `anime: non`, `animations: []`.
   - `layout:` — structure dominante (grille, asymétrique, plein-écran, split, bento…)
   - `mood:` — ambiance
   - `tags:` du vocabulaire d'`INSPIRATION/_INSPIRATION.md` (discipline + mood + `#a-tester`…)
   - intégrer `![home](home.png)` + une galerie `## Pages du site` avec les autres captures
   - « Pourquoi je l'aime » + « À réutiliser pour »
   - **Fiche = maximum d'informations et de mots-clés** : qui (studio/créateur + client, liens), d'où (URL source), quoi (chaque visuel décrit en une ligne), style — et une section `## Mots-clés` libre et généreuse (synonymes FR/EN) en fin de fiche, carburant de la recherche MemPalace (cf. § Mode post social, même règle).
   - **Une valeur manque au vocabulaire** (type_site/animation inédit) ? l'ajouter à `_INSPIRATION.md` et le **signaler** dans le récap (cf. `CLAUDE.md` — rester sobre).
8. **Extraire composants + animations** (jugement — voir § Composants et § Passe animation). **Deux dossiers distincts** dans `INSPIRATION/<DISCIPLINE>/<slug>/` :
   - **Composants statiques** → `composants/` : découper les blocs **vraiment originaux/réutilisables** (footer, hero, index, pricing…) en `.png`. Indexer dans `INSPIRATION/COMPOSANTS/_COMPOSANTS.md`.
   - **Animations** → `animations/` : passe automatique (loader / autoplay / hover / **section animée**), garder les **pépites** en GIF/MP4. Indexer dans `INSPIRATION/ANIMATIONS/_ANIMATIONS.md`.
   - Dans les deux cas : ligne dans l'index global (`![[fichier]]`) + reliée depuis la fiche.
   - **Rien d'original → rien.**
9. **Vidéo walkthrough** (AUTOMATIQUE à chaque site) : `python3 .claude/skills/inspi/walkthrough.py "<url>" "INSPIRATION/<DISCIPLINE>/<slug>/walkthrough.mp4"` → l'intégrer dans la fiche via `![[walkthrough.mp4]]`.
10. **Réindexer MemPalace** : `mempalace mine /Users/smoricet/Documents/KNOWLEDGE --agent sacha`.
11. **Récapituler** : discipline, slug, nb de pages, composants/anims retenus (ou « aucun »), walkthrough, **descripteurs remplis** (type_site, secteur, couleur_principale, anime/animations, layout, mood/tags), et tout cookie-wall / troncature / valeur de vocabulaire ajoutée.

## Mode post social (X, Instagram, Pinterest, TikTok…)

Un post = **le média d'abord** (l'image/la vidéo en pleine qualité, pas un screenshot de l'interface autour). Workflow plus court que pour un site : pas de composants, pas de walkthrough.

1. **Choisir la discipline d'après ce que MONTRE le post**, pas d'après la plateforme : un tweet d'un dashboard → `UI-DESIGN` ; un pin d'affiche → `GRAPHISME` ; un reel de motion → `MOTION` ; une identité sur Behance → `BRAND-DESIGN` ; un screenshot de site → `WEBDESIGN`. (On ne connaît le contenu qu'après téléchargement → on peut lancer l'étape 2 dans un dossier provisoire du scratchpad, regarder, puis déplacer au bon endroit.)
2. **Télécharger le(s) média(s)** :
   ```
   python3 .claude/skills/inspi/grab-post.py "<url>" "INSPIRATION/<DISCIPLINE>/<slug>/"
   ```
   - Le script détecte la plateforme, essaie `gallery-dl` puis `yt-dlp` (ordre inversé pour les plateformes vidéo), renomme proprement (`post.jpg`, `post-2.jpg`, `post.mp4`…) et renvoie un JSON : fichiers + **meta** (auteur, texte/légende, date, likes) + erreurs éventuelles.
   - **Post derrière login** (Instagram surtout, parfois X) : relancer avec `--cookies` (utilise la session Chrome de Sacha ; macOS peut demander UNE FOIS l'accès trousseau « Chrome Safe Storage » — normal). **Limite connue (août 2026)** : Chrome n'exporte plus le cookie `sessionid` d'Instagram → gallery-dl échoue même avec `--cookies`, et yt-dlp ne récupère que les slides **vidéo** d'un carrousel (ses erreurs `No video formats found` signalent les slides image restantes). Dans ce cas : garder les vidéos obtenues, compter les slides, et récupérer les images par la **capture native par tuiles** (§ ci-dessous).
   - **Échec malgré les cookies** (Instagram refuse souvent ses cookies hors navigateur, post privé, plateforme non supportée) : fallback = **capture native par tuiles** (§ ci-dessous), qui donne la **pleine résolution d'origine**, pas un screenshot réduit de l'interface. Le signaler.
3. **Slug** : ce que le post **montre**, en kebab — `<marque/projet>` ou `<sujet>-<qualificatif>` (ex. `bartolomeu-moveis`, `dashboard-sombre-samdape`, `affiche-suisse-rouge`). **PAS de plateforme dans le nom** (elle vit dans le frontmatter `plateforme:`) ; l'auteur seulement s'il faut désambiguïser. Destination `INSPIRATION/<DISCIPLINE>/<slug>/`.
4. **Regarder le média** (`Read` sur les images ; pour une vidéo, extraire 1-2 frames : `ffmpeg -ss 2 -i post.mp4 -frames:v 1 frame.png`) — jugement : sujet, style, couleurs, mood.
5. **Créer la fiche** `<slug>.md` depuis `TEMPLATES/Template-Inspiration-Post.md` : `discipline`, `source` (URL complète du post), `media: post`, `plateforme`, `auteur` (handle/nom depuis le meta JSON), `sujet`, `couleur_principale` + `couleurs`, `mood`, `tags` — même vocabulaire contrôlé que le reste (`_INSPIRATION.md`). Intégrer le média (`![[post.jpg]]` / `![[post.mp4]]`) et reprendre la **légende du post** (champ `texte` du JSON) en citation si elle éclaire le contenu.
   **Fiche = maximum d'informations et de mots-clés** (demande de Sacha : c'est ce qui rend la recherche MemPalace précise). En plus du frontmatter : **qui** (créateur/studio + client/marque, avec liens), **d'où** (plateforme + URL source + compte relais s'il y a curation), **quoi** (décrire chaque média en une ligne : sujet, support, technique), **style** (courant graphique, références, époque), et une section `## Mots-clés` en fin de fiche avec une liste libre et généreuse de termes de recherche (synonymes FR/EN compris : « identité visuelle, branding, logotype, monogramme, wordmark… »). Le vocabulaire contrôlé reste la règle pour le frontmatter ; la section Mots-clés, elle, est **libre** — c'est du carburant de recherche, pas de la taxonomie.
6. **Réindexer MemPalace** puis **récapituler** : discipline, slug, nb de médias, plateforme/auteur, descripteurs remplis, et tout recours aux cookies / fallback screenshot.

**Cas particuliers** :
- **Plusieurs images dans un post** (carrousel Instagram, tweet à 4 images, board…) : tout garder (`post-1.jpg`…`post-4.jpg`), les intégrer toutes dans la fiche.
- **Lien de board/moodboard Pinterest entier** (pas un pin) : ne pas aspirer les 300 pins — demander à Sacha s'il veut le board complet (et si oui borner, ex. 20 premiers pins) ou juste quelques pins précis.
- **Vidéo YouTube/Vimeo entière** : c'est en général une inspi `MOTION` ; la vidéo peut être lourde → si > ~100 Mo, préférer une qualité moindre (`yt-dlp -f "best[height<=1080]"` à la main) et le signaler.
- **Le post pointe vers un site** (tweet « nouveau portfolio → lien ») : demander à Sacha s'il veut le post, le site (mode site), ou les deux.

### Fallback — capture native par tuiles (qualité d'origine, via claude-in-chrome)

Quand `grab-post.py` échoue même avec `--cookies`, on peut quand même récupérer les **images à leur résolution native** (ex. 1440×1440 sur Instagram) sans télécharger de fichier : on affiche l'image en taille réelle dans la page et on la capture en tuiles 1:1 qu'on recolle. Méthode validée (post Instagram `domo-brand-identity`, août 2026).

1. **Ouvrir le post** dans le Chrome de Sacha (`claude-in-chrome`, nouvel onglet, il est connecté aux plateformes).
2. **Lister les slides depuis la SOURCE DE VÉRITÉ, jamais depuis le DOM.** PIÈGE VÉCU (post `logosai`, août 2026) : scraper `article img` / `main img` ramasse les vignettes de la grille « autres posts du compte » en bas de page → on range des images d'AUTRES posts en croyant tenir le carrousel. Ne jamais lister les slides en scrapant les `<img>`. À la place, depuis la page (`javascript_tool`), interroger l'**API interne** avec la session du navigateur :
   - `pk` = shortcode décodé en base64url (`A-Za-z0-9-_`, `pk = pk*64 + index(c)`) ;
   - `fetch('https://www.instagram.com/api/v1/media/<pk>/info/', {headers:{'x-ig-app-id':'936619743392459'}, credentials:'include'})` → `items[0].carousel_media[]` : `media_type` (1=image, 2=vidéo), `image_versions2.candidates` (prendre la plus grande). *(Fallback si l'API change : le JSON embarqué `script[type="application/json"]` contenant `carousel_media`.)*
   - **Vérifier le compte** : nb de slides + types doivent coller au post (le compteur « x/8 » visible sur le carrousel). Croiser avec yt-dlp : ses erreurs `No video formats found` sur des slides = ce sont des images (normal), et lui seul télécharge les slides **vidéo**.
   Stocker les URLs dans `window.__slides`, puis `fetch` chaque image et garder son base64 dans `window.__b64`. **Ne renvoyer que des compteurs/dimensions** dans le résultat d'outil.
   - **INTERDIT** : faire sortir les URLs ou le base64 par la sortie d'outil — le filtre anti-exfiltration de l'extension les bloque (`[BLOCKED: …]`) et il ne faut **pas** le contourner par un autre encodage.
   - **Voies mortes déjà testées** (ne pas re-perdre de temps) : `a.click()` + blob download (bloqué sans geste utilisateur réel, même via clic simulé), POST vers un serveur localhost (bloqué par la CSP du site), `curl` du HTML du post (données absentes sans session). Un **vrai clic de Sacha** sur un bouton injecté reste une option de secours pour un téléchargement direct.
3. **Overlay taille native** : injecter un `<div>` fixed plein écran (z-index max) contenant une `<img>` à la **taille native en px CSS** (ex. `width:1080px`). Source de l'img : la **data URL base64** OU, si elle sort en image cassée (la CSP d'Instagram bloque `data:` sur les pages **anonymes**), directement l'**URL CDN** (`img.src = url` — les `<img>` ne sont pas soumis au CORS). Toujours **attendre `onload`** et vérifier `naturalWidth` avant de capturer. Masquer l'UI de la plateforme par un `<style>` injecté (survit aux re-renders React, contrairement aux styles inline). NB : la méthode marche aussi **déconnecté** — le JSON embarqué du post anonyme contient les slides (`candidates[0].url` peut ne pas avoir de `width` → prendre `candidates[0]` + `original_width`, pas un reduce sur `width`).
4. **Mesurer le viewport réel** après `resize_window` au maximum : `innerWidth/innerHeight` + `devicePixelRatio` via JS. Les régions de l'action `zoom` sont en **pixels physiques** du viewport. Attention : `resize_window` a déjà **fait planter Chrome** (le relancer : `open -a "Google Chrome"`, retrouver l'onglet, tout réinjecter) — s'en passer si le viewport suffit.
5. **Capturer en tuiles ≤ 720×720** : action `zoom` + `save_to_disk`. Au-delà de ~1400 px de région, l'outil **redimensionne** la sortie (perte) ; à 720 la tuile sort **1:1**. Entre les tuiles, déplacer l'image par `transform: translate(...)` à **décalages entiers** (ex. 1080×1080 = 4 tuiles de 540, ordre TL TR BL BR).
   **Étalonner l'échelle réelle sur la 1ʳᵉ tuile, ne pas faire confiance au dpr** : le zoom Chrome (≠ 100 %) fausse le rapport device/CSS (vécu : région 540 demandée → tuile 1092 couvrant 617 px CSS, soit 1,7685 device/CSS). Méthode : capturer la tuile TR (`translate(-540px,0)`), mesurer en PIL la **colonne du bord droit du contenu** (`x_bord`) → échelle = `x_bord / (largeur_image − 540)` ; assembler ensuite en collant chaque tuile à `(540·échelle, 0)` etc. sur un canvas device, cropper à `largeur_image·échelle`, redimensionner LANCZOS à la taille native.
6. **Recoller** :
   ```
   python3 .claude/skills/inspi/stitch.py <sortie.png> --cols 2 tuile1.png tuile2.png tuile3.png tuile4.png
   ```
   (tuiles en ordre **ligne par ligne**). Relire le résultat pour vérifier l'absence de raccord.
7. **Nettoyer** : fermer l'onglet. Signaler dans le récap que la qualité vient de la capture du rendu (visuellement identique au fichier source, mais pas les octets d'origine).

Cette méthode ne vaut que pour des **images** — pour une vidéo irrécupérable, fallback = `record.py` sur le post ou frame unique, le signaler.

## Composants statiques (sélectif)

> **Deux dossiers, deux index** : `composants/` = blocs UI statiques (`.png`) → [[_COMPOSANTS]] ; `animations/` = sections / intros / micro-anims (`.gif`/`.mp4`) → [[_ANIMATIONS]]. Une **section qui s'anime** va dans `animations/`, pas dans `composants/` (cf. § Passe animation).

- **Où** : les composants statiques vivent **dans le dossier du site** → `INSPIRATION/<DISCIPLINE>/<slug>/composants/<type>_<slug>.png` (contexte préservé, dossier site auto-suffisant). Le **suffixe `_<slug>`** garde les noms uniques pour l'index global.
- **Ne pas tout prendre** : pas un composant par section. Seulement ce qui sort du lot. **Rien d'original → rien à extraire** (le dire). Sauf si Sacha demande un composant précis.
- **Comment** : regarder les captures pleine hauteur, repérer le composant, le **découper** :
  ```
  python3 .claude/skills/inspi/crop.py "<capture.png>" "INSPIRATION/<DISCIPLINE>/<slug>/composants/<type>_<slug>.png" --box <x> <y> <w> <h>
  ```
  (ou `--band <y_haut> <y_bas>` pour une bande pleine largeur). Coordonnées en pixels de l'image **source**. Vérifier le découpage en le relisant, ajuster si besoin.
- **Indexer** : ajouter une ligne à l'index global `INSPIRATION/COMPOSANTS/_COMPOSANTS.md` (type, source `[[fiche]]`, pourquoi, `![[fichier]]`) + relier depuis la fiche d'inspi. Le fichier n'est PAS déplacé : l'index ne fait que le référencer.
- Si Sacha demande un composant précis (« prends-moi le footer »), le faire même s'il est banal.

### Passe animation — AUTOMATIQUE & sélective (GIF/MP4)

À faire **automatiquement** à chaque `/inspi`, mais en ne gardant que ce qui est **vraiment cool/stylé** (même exigence que pour les composants — rien de marquant → rien). Outil :
```
python3 .claude/skills/inspi/record.py "<url>" "INSPIRATION/<DISCIPLINE>/<slug>/animations/<type>_<slug>.gif" \
    [--seconds 4 --fps 12 --delay 0 --box x y w h --hover-selector "css" --scroll-from Y0 --scroll-to Y1]
```

**4 choses à tenter (et à juger en regardant le résultat) :**
1. **Loader** — toujours enregistrer les ~4 premières s de la home (`--delay 0`). Le **regarder** : si c'est un loader **cool/original** → garder (`loader_<slug>.gif`) ; si c'est un spinner/fondu banal → **jeter**.
2. **Animation autoplay** (hero animé, motion de fond, canvas) — si une zone bouge visiblement, l'enregistrer (cadrer avec `--box`). Garder si stylé.
3. **Hover** — survoler un **petit set** de candidats clés (nav principale, bouton/CTA, 1ʳᵉ carte projet) avec `--hover-selector`. **Cap : ~3 candidats max.** Garder seulement les hovers **vraiment stylés** (transition, reveal, déformation…), pas un simple changement de couleur.
4. **Sections animées au scroll / longues animations de section** — c'est le cœur de beaucoup de beaux sites (ex. le **header de Ribbit** qui se déploie longuement, la **carte « Process »** qui se révèle au défilement). Dès qu'une **section entière s'anime joliment** (au chargement OU au scroll), la prendre en GIF, pas juste en screenshot figé :
   - **Header / hero à longue anim** : `--delay 0 --seconds 5` (plus long que 4 s pour laisser l'anim se dérouler), éventuellement `--box` pour cadrer le hero.
   - **Section révélée au scroll** (carte, bloc qui apparaît, parallaxe, texte qui traverse) : utiliser **`--scroll-from Y0 --scroll-to Y1`** → la page défile pendant la capture et déclenche l'animation. Repérer le `Y` de la section sur la capture pleine hauteur (coordonnées pixel de l'image source) et balayer autour (ex. `--scroll-from 1800 --scroll-to 3200`).
   - Nommer par la section : `header_<slug>.gif`, `process_<slug>.gif`, `hero_<slug>.gif`…

**Sélectivité** : objectif = quelques pépites animées, pas tout filmer. Si rien ne sort du lot → ne rien garder (le dire). Mais une **section qui s'anime vraiment bien mérite presque toujours un GIF** plutôt qu'un screenshot mort.
**Sortie** : `.gif` (s'anime dans Obsidian, idéal petit format) ou `.mp4` (ffmpeg, plus léger/net en grand). Ranger dans `<site>/animations/` (PAS `composants/`), indexer dans `_ANIMATIONS.md`.

**Limites** : débit réel ~4-8 fps sur pages lourdes (`--fps` = plafond). Hover/clic = simulation best-effort (peut rater une anim complexe). **Vidéo YouTube/Vimeo** : pas récupérable en vidéo (DRM/streaming) → on prend sa **frame** (miniature), pas le flux.

### Vidéo walkthrough du site complet (AUTOMATIQUE)

**À générer systématiquement** à chaque `/inspi` — vidéo de tout le site (défilement auto de chaque page, assemblé en un seul MP4) :
```
python3 .claude/skills/inspi/walkthrough.py "<url>" "INSPIRATION/<DISCIPLINE>/<slug>/walkthrough.mp4" [--fps 10 --speed 500 --hold 0.8 --max-pages 8 --pages "/,/about"]
```
- Découvre les pages (1 par template), charge le lazy-load + frames vidéo, scrolle chaque page haut->bas, concatène en `walkthrough.mp4`.
- L'intégrer dans la fiche : `![[walkthrough.mp4]]`.
- C'est l'étape la plus longue (plusieurs lancements Chrome) → la faire en dernier. Sur un **très gros site**, borner avec `--max-pages` et le signaler.

## Structure produite

```
INSPIRATION/<DISCIPLINE>/<slug>/
├── <slug>.md             ← fiche : lien + captures intégrées + mood/tags
├── home.png              ← capture PLEINE HAUTEUR
├── <page>.png …          ← pages racine uniques (about, shop…)
├── <groupe>-template.png ← 1 exemple par template (ex. works-template.png)
├── walkthrough.mp4       ← vidéo de tout le site (auto)
├── composants/           ← blocs UI statiques réutilisables (dans le projet)
│   └── <type>_<slug>.png
└── animations/           ← sections / intros / micro-anims marquantes (dans le projet)
    └── <type>_<slug>.gif|mp4

INSPIRATION/COMPOSANTS/_COMPOSANTS.md   ← INDEX transversal des composants (référence, ne stocke pas)
INSPIRATION/ANIMATIONS/_ANIMATIONS.md   ← INDEX transversal des animations (référence, ne stocke pas)
```

**Pour un post social** (structure plus légère) :
```
INSPIRATION/<DISCIPLINE>/<slug>/          ← ex. bartolomeu-moveis (pas de plateforme dans le nom)
├── <slug>.md          ← fiche : source + média(s) intégré(s) + plateforme/auteur/mood/tags
├── post.jpg           ← média(s) du post en pleine qualité (post-2.jpg… si carrousel)
└── post.mp4           ← si le post est une vidéo (ou post.png si fallback screenshot)
```

## Limites (à signaler, pas à cacher)

- **Découverte des pages** = liens présents sur la **home** (1 niveau). Des pages profondes non liées depuis l'accueil peuvent manquer → si Sacha veut une page précise non trouvée, lui demander l'URL et utiliser `--pages`.
- **Images lazy-load** : le capteur **scrolle toute la page** avant la capture pour les déclencher (sinon zones blanches). **Vidéos** : les `<video>` HTML5 sont lancées en muet (capture d'une frame) et les **embeds YouTube sont remplacés par leur miniature** (= une frame de la vidéo, sinon ils sortent blancs en headless). Limite : **Vimeo / players custom** peuvent rester blancs → le signaler et proposer un screenshot manuel.
- **Cookie-walls / RGPD** peuvent masquer une capture. **Préchargeurs** (Framer/SPA) : le `--budget` à 16 s les évite la plupart du temps ; si une capture sort en « loading… », **recapturer** avec un budget plus long (ex. `--budget 25000`) ou demander un screenshot manuel.
- **Login / paywall** : pages protégées non capturables → le signaler.
- **Gros sites** : au-delà de `--max`, troncature signalée → demander à Sacha s'il veut tout.
- **Posts sociaux** : Instagram exige presque toujours `--cookies` ; X marche en général sans, mais peut se mettre à exiger un login (relancer avec `--cookies`). Post **privé** ou plateforme non supportée → fallback screenshot via claude-in-chrome (§ Mode post social). Les **stories** Instagram (éphémères) et les posts supprimés ne sont pas récupérables.

## Garde-fous

- Ne pas écraser une inspi existante (même slug) → mettre à jour ou suffixe.
- Les captures vivent **dans le dossier de l'inspi** (le livrable), jamais dans le scratchpad.
- Vocabulaire de tags **contrôlé** (comme pour les fonts) : réutiliser l'existant, pas de synonyme inventé.

## Étape finale — sync SorduloInspiration

Après toute création ou mise à jour de fiche, lancer
`npm run sync --prefix ~/Documents/GitHub/SORDULO/SorduloInspiration`
et inclure son récap (ajouté / mis à jour / supprimé) dans le compte-rendu.
