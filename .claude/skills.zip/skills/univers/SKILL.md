---
name: univers
description: À partir d'un NOM (jeu vidéo, marque, studio, film, série…), fait une recherche web en éventail pour rapatrier tous les médias créatifs de cet univers (branding/logos, UI/menus, character design/concept art, illustrations/key art, animations/trailers, gameplay/produit) en pleine qualité, et crée un dossier de référence permanent dans INSPIRATION/UNIVERS/ avec une fiche cherchable. À utiliser quand Sacha dit « fais-moi le dossier de tel jeu/marque », « recherche tout sur X », « je veux les références de X ».
---

# /univers — Dossier de référence complet sur un univers créatif

Transforme un **nom** (pas une URL — pour une URL, c'est `/inspi`) en **dossier de référence permanent** : les médias eux-mêmes, téléchargés en pleine qualité, rangés par aspect + une fiche cherchable. Objectif : que les données **ne disparaissent jamais**, même si les sources en ligne meurent.

Marche pour **n'importe quel univers** : jeu vidéo, marque, studio, film, série, musicien, événement…

## Procédure

1. **Identifier l'univers.** Si le nom est ambigu (plusieurs jeux/marques homonymes), demander. Noter le **focus** éventuel de Sacha (« surtout la DA », « juste les logos ») → il pondère la recherche.

2. **Recherche en éventail** (WebSearch/WebFetch ; pour un gros univers, lancer des **agents parallèles**, un par angle). Chercher dans cet ordre de fiabilité :
   - **Sources officielles** : site officiel, press kit (souvent `presskit()` / page « press »), comptes officiels, pages stores (Steam, App Store…).
   - **Artistes crédités** : identifier qui a fait quoi (art director, character designer, illustrateurs, studios d'animation des trailers) et retrouver leurs **portfolios** (ArtStation, Behance, site perso) — c'est là que vivent les concept arts et process.
   - **Bases spécialisées** : Game UI Database (gameuidatabase.com) pour les UI de jeux, wikis de fans (screenshots, sprites), Fonts In Use / Brands of the World pour les marques, Art of the Title pour les génériques…
   - **Vidéo** : chaînes YouTube/Vimeo officielles (trailers, making-of, devlogs, showreels des studios d'animation).
   Chaque angle doit rendre des **URLs directes de médias** (ou de pages téléchargeables), pas des descriptions.

3. **Adapter les aspects à l'univers.** Base commune : `branding/` (logos, identité), `illustrations/` (key art, artworks), `animations/` (trailers, motion, GIF/MP4). Puis selon le cas :
   - **Jeu vidéo** : + `ui/` (menus, HUD, boutons, écrans), `character-design/` (mascotte, concept art, turnarounds, sprites), `gameplay/` (screenshots in-game).
   - **Marque** : + `campagnes/` (pubs, affiches, activations), `produit/` (packaging, objets), éventuellement `historique/` (anciens logos, évolutions).
   - Ne créer un sous-dossier **que s'il aura du contenu**. Autre aspect pertinent → le créer (rester sobre).

4. **Télécharger en pleine qualité** dans `INSPIRATION/UNIVERS/<slug>/<aspect>/` :
   - Images directes / press kits : `curl -L` (prendre la **plus grande résolution** disponible — fichier source du press kit, pas la vignette).
   - Portfolios (ArtStation, Behance, Pinterest…) : `gallery-dl` (cibler le **projet précis**, pas tout le compte).
   - Vidéos : `yt-dlp -f "bestvideo[height<=1080]+bestaudio/best[height<=1080]"` → `.mp4`. Si > ~150 Mo, baisser la qualité et le signaler. Une micro-anim qui mérite la boucle → convertir un extrait en GIF (`ffmpeg`).
   - **Nommage descriptif en kebab** : `logo-principal.png`, `menu-principal.jpg`, `concept-narinder.jpg`, `trailer-lancement.mp4`… jamais `image(3).jpg`.
   - **Volume** : viser la qualité, pas l'exhaustivité — **~30 à 60 médias forts** par défaut (plus si Sacha demande « tout »). Toute troncature/échec de téléchargement → **signaler, jamais silencieux**.

5. **Vérifier un échantillon** (`Read` sur quelques images par aspect) : bonne résolution, bon contenu, rien de hors-sujet. Virer les doublons et les vignettes basse qualité.

6. **Créer la fiche** `INSPIRATION/UNIVERS/<slug>/<slug>.md` depuis `TEMPLATES/Template-Univers.md` :
   - Frontmatter : `type: univers`, `categorie` (jeu-vidéo/marque/studio/film…), `secteur`, `annee`, `createurs`, `source` (site officiel), `couleur_principale` + `couleurs` (observées sur les médias), `mood`, `tags`.
   - **Une section par aspect** avec galerie intégrée (`![[fichier]]`) et une ligne de description par média marquant.
   - **Section « Artistes & crédits »** : qui a fait quoi, avec **liens vers les portfolios** — c'est une des grandes valeurs du dossier.
   - **Sources** : lister les URLs d'origine (press kit, pages, vidéos) pour pouvoir y retourner.
   - « Pourquoi je l'aime » + « À réutiliser pour » + section `## Mots-clés` **libre et généreuse** (FR/EN, synonymes) — carburant MemPalace.

7. **Indexer** : ajouter une ligne dans `INSPIRATION/UNIVERS/_UNIVERS.md` (univers, catégorie, aspects couverts, lien `[[fiche]]`).

8. **Réindexer MemPalace** : `mempalace mine /Users/smoricet/Documents/KNOWLEDGE --agent sacha`.

9. **Sync SorduloInspiration** : `npm run sync --prefix ~/Documents/GitHub/SORDULO/SorduloInspiration` et inclure son récap.

10. **Récapituler** : slug, aspects créés, nb de médias par aspect, artistes identifiés, vidéos (taille), et tout échec/troncature/source inaccessible.

## Structure produite

```
INSPIRATION/UNIVERS/<slug>/
├── <slug>.md            ← fiche : sources + crédits + galeries + mood/tags + mots-clés
├── branding/            ← logos, identité, lockups (anciens logos si pertinent)
├── ui/                  ← menus, HUD, boutons, écrans (jeux/apps)
├── character-design/    ← mascotte, concept art, turnarounds, sprites
├── illustrations/       ← key art, artworks, affiches
├── animations/          ← trailers, motion, micro-anims (.mp4/.gif)
└── gameplay/            ← screenshots in-game (ou campagnes/, produit/… selon l'univers)
```

## Garde-fous

- **Usage = référence personnelle** dans le vault (pas de republication) ; toujours **sourcer** chaque famille de médias dans la fiche.
- Ne pas écraser un dossier d'univers existant (même slug) → **compléter** l'existant.
- Pleine qualité d'abord : jamais une vignette quand le fichier source existe.
- Slug en kebab, sous-dossiers d'aspect en minuscules.
- Vocabulaire de tags contrôlé (`_INSPIRATION.md`) pour le frontmatter ; la section Mots-clés reste libre.
